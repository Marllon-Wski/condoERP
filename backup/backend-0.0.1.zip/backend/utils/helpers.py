
import logging
from flask import Flask, jsonify, request, abort
import mysql.connector
from mysql.connector import Error
from dotenv import load_dotenv
from datetime import date, datetime
from decimal import Decimal

from backend.config import DB_CONFIG, logger


# ── Helpers ───────────────────────────────────────────────


def get_connection():
    # Abre e retorna uma conexão com o banco.
    try:
        conn = mysql.connector.connect(**DB_CONFIG)
        return conn
    except Error as e:
        logger.error("Erro de conexão: %s", e)
        abort(503, description="Não foi possível conectar ao banco de dados.")


def serialize(obj):
    # Serializa tipos especiais para JSON.
    if isinstance(obj, (date, datetime)):
        return obj.isoformat()
    if isinstance(obj, Decimal):
        return float(obj)
    return obj


def row_to_dict(cursor, row):
    # Converte uma linha de resultado em dicionário.
    return {
        col[0]: serialize(val)
        for col, val in zip(cursor.description, row)
    }


def rows_to_list(cursor):
    # Converte todas as linhas em lista de dicionários.
    return [row_to_dict(cursor, row) for row in cursor.fetchall()]


def json_ok(data, status=200):
    return jsonify({"sucesso": True,  "dados": data}), status


def json_created(data):
    return jsonify({"sucesso": True,  "dados": data}), 201


def json_error(msg, status=400):
    return jsonify({"sucesso": False, "erro": msg}), status
